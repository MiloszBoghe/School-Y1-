naam = string(input("Geef de spelersnaam: "))
prijs_vorig = float(input("Geef de prijs van het vorige seizoen: "))
leeftjid = int(input("leeftijd: "))
gem_beoordelingscijfer = int(input("geef een getal van 0-10: "))





print("naam: ",naam, "prijs vorig seizoen: ", prijs_vorig, "nieuwe prijs: ", nieuwe_prijs)