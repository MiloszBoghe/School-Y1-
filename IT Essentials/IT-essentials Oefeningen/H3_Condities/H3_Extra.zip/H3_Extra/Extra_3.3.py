bedrag = 25
waterverbruik = int(input("Geef het verbruikte water in kubieke meter: "))

if waterverbruik <= 30:
    print ("De prijs is ", bedrag, "euro")
elif waterverbruik <= 200:
    bedrag += 1*(waterverbruik-30)
elif waterverbruik <= 5000:
    bedrag += 169 + 1.15 * (waterverbruik - 200)
else:
    bedrag += 169 + 1.15 * 4799 + 1.175 * (waterverbruik-4999)
print ("De prijs is ", bedrag, "euro")