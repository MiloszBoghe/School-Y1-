getal_a = float(input("Geef een getal: "))
getal_b = float(input("Geef een getal: "))
getal_c = float(input("Geef een getal: "))

if getal_a + getal_b < 20:
    som = getal_a + getal_b + getal_c
    print("som: ",som)
else:
    print("te groot")